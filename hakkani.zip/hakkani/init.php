<?php


/*

plugin name:Hakkani Plugin
Plugin URI:http://www.mimit.com
Author:Golam Hakkani mim
Author URI:htttp://www.mimHakkani.com
version:1.1.1.1
description:This is The First Plugin To Pratices the theme development i love the plugin development ...this is so interseting plugin develiopment.
License:GPLv2 or later
Text Domain:hakkani 


*/




/*

For custom post type 

*/

add_action('after_setup_theme','customf');

function customf(){

register_post_type('plugin',[

	'public'		=>true,
	'labels'		=>[

		'name'		=>'Hakkani Info',
		'add_new'	=>'Add Hakkani Info',
		'all_items'=>'All Hakkani Items Info',
		'add_new_item'=>'Hakkani New Info'


	],

	'supports'		=>['title','thumbnail','editor']


]);



/*
 set up the menus 

*/




}



add_action('widgets_init','amar_pwid');
function amar_pwid(){

register_sidebar([

	'name'		=>'Amar Plugin er Widget',
	'id'		=>'apew',
	'description'=>'when install the hakkani plugin then automatic add this plugins'

]);

register_widget('Hakkaninfo');


}

class Hakkaninfo extends WP_Widget{

public function __construct(){

	parent::__construct('Hakkani Info','Hakkaninfo',[

		'description'	=>'Details About the Own Information'

	]);
}


public function widget($one,$two){ 

$name = $two['pi'];

?>


<!-- html output is here -->



<?php }


public function form($two){  

$name = $two['pi'];

	?>


  <label for="">Name : </label>
	<p>
		<input type="text" name="<?php echo $this->get_field_name('pi') ?>" value="<?php echo $name  ?>" class="widefat">
	</p>



<?php }



}


// end of widget all functions




/*
 css js link up functions started 

*/


add_action('wp_enqueue_scripts',function(){


wp_enqueue_style('normalize',PLUGINS_URL('assets/css/normalize.css',__FILE__));
wp_enqueue_style('responsive',PLUGINS_URL('assets/css/responsive.css',__FILE__));
wp_enqueue_style('style',PLUGINS_URL('assets/css/style.css',__FILE__));
wp_enqueue_style('font-awesome',PLUGINS_URL('assets/css/font-awesome.min.css',__FILE__));
wp_enqueue_style('bootstrap',PLUGINS_URL('assets/css/bootstrap.min.css',__FILE__));


wp_enqueue_script('jquery');
wp_enqueue_script('popper',PLUGINS_URL('assets/js/popper.min.js',__FILE__),['jquery'],true,true);
wp_enqueue_script('bootstrap2',PLUGINS_URL('assets/js/bootstrap.min.js',__FILE__),['jquery'],true,true);




});


/*

 css js link up functions ended


*/


/********************************************        shortcode                **************************************/


add_shortcode('amarinfo','amarinfo');

function amarinfo($one,$two){


	$stt =  shortcode_atts([

		'name'		=>' ',
		'fname'		=>' ',
		'ing'		=>' ',
		'bimg'		=>' ',

	],$one);


	ob_start()  ?>


<div class="container myinfo">
	<?php 

		$bimg = wp_get_attachment_url($stt['bimg'],'full');

	 ?>
	<img src="<?php echo $bimg ; ?>" alt="" class="rounded-circle">
	<h4>Name : <?php echo $stt['name'] ?></h4>
	<h4>Father Name : <?php echo $stt['fname'] ?></h4>
	<p>University: <?php echo $stt['ing']?></p>
</div>



	<?php 

	return ob_get_clean();




}


add_action('vc_before_init','mim');
function mim(){
/* for add the vc maps */
	if( function_exists('vc_map') ){

 vc_map([

			'name'			=> 'Hakkani',
			'base'			=> 'amarinfo',
			'description'	=> 'Comet custom box',
			'category'		=>'Personal',
			'params'			=>[


	            [
					'param_name'			=> 'fname',
					'type'					=> 'textfield',
					'heading'				=> 'father',
					'description'			=> 'comet amar'
					
				],

				 [
					'param_name'			=> 'ing',
					'type'					=> 'textfield',
					'heading'				=> 'university',
					'description'			=> 'keni asse na bujlam na'
					
				],
				 [
					'param_name'			=> 'name',
					'type'					=> 'textfield',
					'heading'				=> 'Boass Name',
					'description'			=> 'Boss is here please ...'
					
				],
				[
					'param_name'			=> 'bimg',
					'type'					=> 'attach_image',
					'heading'				=> 'Boass image',
					'description'			=> 'Boss is here please ...'
					
				],
				
				
				

			]



			
			
		]);
	};


	
}














/*cmb link up */
require 'assets/cmb/init.php';
require 'assets/cmb/cmb-config.php';
























 ?>