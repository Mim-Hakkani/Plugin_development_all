<?php


/*

plugin name:Doctors slider details
Plugin URI:http://www.mimit.com
Author:Golam Hakkani mim
Author URI:htttp://www.mimHakkani.com
version:1.1.1.1
description:This is The First Plugin To Pratices the theme development i love the plugin development ...this is so interseting plugin develiopment.
License:GPLv2 or later
Text Domain:hakkani 


*/




/*

For custom post type 

*/

add_action('after_setup_theme','doctors');

function doctors(){

register_post_type('dinfo',[

	'public'		=>true,
	'labels'		=>[

		'name'		=>'Doctors Info',
		'add_new'	=>'Add Doctors Info',
		'all_items'=>'All Doctors Items Info',
		'add_new_item'=>'Doctors New Info'


	],

	'supports'		=>['title','thumbnail'],
	'menu_icon'			=>'dashicons-plus-alt',


]);



/*
 set up the menus 

*/




}



add_action('widgets_init','doc_pwid');
function doc_pwid(){

register_sidebar([

	'name'		=>'Amar doctors Widget',
	'id'		=>'apew',
	'description'=>'when install the hakkani plugin then automatic add this plugins'

]);

register_widget('doctorinfo');


}

class doctorinfo extends WP_Widget{

public function __construct(){

	parent::__construct('Doctor_Details','doctorinfo',[

		'description'	=>'Details About the doctor Own Information'

	]);
}


public function widget($one,$two){ 

$dname 	= $two['dname'];
$dd 	= $two['dgree'];
$dsp 	= $two['dsp'];
$dpn 	= $two['dpn'];
$dhos 	= $two['dhos'];
$dmail	= $two['dmail'];

?>


<div class="container">

	<div class="row ">
		
		<div class="owl-carousel">
		
			  <div class="doc-details">
			
			    <img src="images/d1.jpg" alt="" class="rounded-circle">
			    <h3>Name :  <?php echo $dname; ?> </h3>
			    <p><strong>Speciality :</strong> <?php echo $dsp ;?>  </p>
			    <p><strong>Phone : </strong> <?php echo $dpn  ;?> </p>
			    <p><strong>Degree :</strong> <?php echo $$dd  ;?> </p>
			    <p><strong>Hospital : </strong> <?php echo $dhos ;?></p>
			    <p><strong>Email : </strong><?php echo $dmail ;?> </p>


		    </div>
		
	    </div>

    </div>
</div>





<?php }


public function form($two){  

$dname 	= $two['dname'];
$dd 	= $two['dgree'];
$dsp 	= $two['dsp'];
$dpn 	= $two['dpn'];
$dhos 	= $two['dhos'];
$dmail	= $two['dmail'];

	?>


  <label for="">Name : </label>
	<p>
		<input type="text" name="<?php echo $this->get_field_name('dname') ?>" value="<?php echo $dname   ?>" class="widefat">
	</p>

	<label for="">degree : </label>
	<p>
		<input type="text" name="<?php echo $this->get_field_name('dgree') ?>" value="<?php echo $dd   ?>" class="widefat">
	</p>

<label for="">specalist : </label>
	<p>
		<input type="text" name="<?php echo $this->get_field_name('dsp') ?>" value="<?php echo $dsp  ?>" class="widefat">
	</p>

<label for="">phone : </label>
	<p>
		<input type="text" name="<?php echo $this->get_field_name('dpn') ?>" value="<?php echo $dpn   ?>" class="widefat">
	</p>

<label for="">hospital : </label>
	<p>
		<input type="text" name="<?php echo $this->get_field_name('dhos') ?>" value="<?php echo $dhos  ?>" class="widefat">
	</p>
	<label for="">email : </label>
	<p>
		<input type="text" name="<?php echo $this->get_field_name('dmail') ?>" value="<?php echo $dmail  ?>" class="widefat">
	</p>





<?php }



}


// end of widget all functions




/*
 css js link up functions started 

*/


add_action('wp_enqueue_scripts',function(){


wp_enqueue_style('normalize',PLUGINS_URL('assets/css/normalize.css',__FILE__));
wp_enqueue_style('responsive',PLUGINS_URL('assets/css/responsive.css',__FILE__));
wp_enqueue_style('style',PLUGINS_URL('assets/css/style.css',__FILE__));
wp_enqueue_style('font-awesome',PLUGINS_URL('assets/css/font-awesome.min.css',__FILE__));
wp_enqueue_style('carousel2',PLUGINS_URL('assets/css/owl.carousel.min.css',__FILE__));
wp_enqueue_style('carousel3',PLUGINS_URL('assets/css/owl.theme.dafault.min.css',__FILE__));
wp_enqueue_style('bootstrap',PLUGINS_URL('assets/css/bootstrap.min.css',__FILE__));


wp_enqueue_script('jquery');
wp_enqueue_script('popper',PLUGINS_URL('assets/js/popper.min.js',__FILE__),['jquery'],true,true);
wp_enqueue_script('carousel',PLUGINS_URL('assets/js/owl.carousel.min.js',__FILE__),['jquery'],true,true);
wp_enqueue_script('bootstrap',PLUGINS_URL('assets/js/bootstrap.min.js',__FILE__),['jquery'],true,true);
wp_enqueue_script('custom',PLUGINS_URL('assets/js/custom.js',__FILE__),['jquery'],true,true);




});


/*

 css js link up functions ended


*/


/********************************************        shortcode                **************************************/


add_shortcode('docinfo','docinfo');

function docinfo($one,$two){


	$stt =  shortcode_atts([

		'name'		=>' ',
		'fname'		=>' ',
		'ing'		=>' ',
		'bimg'		=>' ',

	],$one);


	ob_start()  ?>


<div class="container">

	<div class="row ">
		
		<div class="owl-carousel">

			<?php 
			$dslider = new WP_Query([

				'post_type'		=>'dinfo',
				'posts_per_page'=> -1,


			]);



			while($dslider->have_posts()):$dslider->the_post()

			 ?>
		
			<div class="doc-details">
			
			    
			    <?php the_post_thumbnail('dinfo',[

			    	'class' => 'rounded-circle'

			    ]); ?>
			    <h3>Name : <?php echo get_post_meta(get_the_id(),'n',true )?>  </h3>

			    <p><strong>Phone : </strong><?php echo get_post_meta(get_the_id(),'p',true )?>  </p>

			    <p><strong>Speciality :</strong> <?php echo get_post_meta(get_the_id(),'s',true )?>  </p>

			    <p><strong>Degree :</strong><?php echo get_post_meta(get_the_id(),'d',true )?> </p>

			    <p><strong>Hospital : </strong> <?php echo get_post_meta(get_the_id(),'h',true )?> </p>

			    <p><strong>Email : </strong><?php echo get_post_meta(get_the_id(),'e',true )?>  </p>


		    </div>

		<?php endwhile; ?>



		</div>
	</div>
</div>




	<?php 

	return ob_get_clean();




}


add_action('vc_before_init','mimdoctor');
function mimdoctor(){
/* for add the vc maps */
	if( function_exists('vc_map') ){

 vc_map([

			'name'			=> 'Doctors Information',
			'base'			=> 'docinfo',
			'description'	=> 'doctors custom box',
			'category'		=>'Doctors',
			'params'			=>[


	            [
					'param_name'			=> 'fname',
					'type'					=> 'textfield',
					'heading'				=> 'father',
					'description'			=> 'comet amar'
					
				],
			
				

			]



			
			
		]);
	};


	
}














/*cmb link up */
require 'assets/cmb/init.php';
require 'assets/cmb/cmb-config.php';
























 ?>