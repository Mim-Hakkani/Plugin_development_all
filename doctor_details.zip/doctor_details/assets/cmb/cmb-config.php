<?php 

add_action('cmb2_init','amader_doctor');

  

  function amader_doctor(){


   
  $pinfo = new_cmb2_box([

        'title'   => 'Doctors Details',
        'id'    => 'dtailsh',
        'object_types'  => ['dinfo']


  ]);

    $pinfo->add_field([

    'name'    =>' Name',
    'type'      =>'text',
    'id'       =>'n'


    ]);


$pinfo->add_field([

    'name'    =>'phone',
    'type'      =>'text',
    'id'       =>'p'


    ]);

$pinfo->add_field([

    'name'    =>'Special',
    'type'      =>'text',
    'id'       =>'s'


    ]);

$pinfo->add_field([

    'name'    =>'Degree',
    'type'      =>'text',
    'id'       =>'d'


    ]);

$pinfo->add_field([

    'name'    =>'Email',
    'type'      =>'text',
    'id'       =>'e'


    ]);

$pinfo->add_field([

    'name'    =>'Hospital',
    'type'      =>'text',
    'id'       =>'h'


    ]);







}













 ?>